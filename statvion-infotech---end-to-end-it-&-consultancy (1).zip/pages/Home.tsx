
import React from 'react';
import { PageContent, Service, RoutePath } from '../types';
import { ArrowRight, CheckCircle2, Cpu, BarChart3, Code2, Smartphone, Database, Cloud } from 'lucide-react';

const iconMap: Record<string, any> = {
  Cpu, BarChart3, Code2, Smartphone, Database, Cloud
};

interface HomeProps {
  content: PageContent;
  services: Service[];
}

const Home: React.FC<HomeProps> = ({ content, services }) => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 pt-32 pb-24 lg:pt-48 lg:pb-40">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 -left-4 w-72 h-72 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
          <div className="absolute top-0 -right-4 w-72 h-72 bg-indigo-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
          <div className="absolute -bottom-8 left-20 w-72 h-72 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block py-1 px-3 mb-6 rounded-full bg-blue-500/10 text-blue-400 text-sm font-bold tracking-wider uppercase border border-blue-500/20">
            Next-Gen IT Consulting
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight mb-8">
            {content.heroTitle}
          </h1>
          <p className="max-w-3xl mx-auto text-lg md:text-xl text-slate-400 mb-10 leading-relaxed">
            {content.heroSubtitle}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href={`#${RoutePath.CONTACT}`} className="bg-blue-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-2 group">
              Start Your Journey <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href={`#${RoutePath.SERVICES}`} className="bg-slate-800 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-700 transition-all border border-slate-700">
              Explore Services
            </a>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-blue-600 font-bold uppercase tracking-widest text-sm mb-4">Our Expertise</h2>
            <h3 className="text-3xl md:text-5xl font-bold text-slate-900 mb-6">End-to-End Solutions</h3>
            <div className="w-20 h-1.5 bg-blue-600 mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.slice(0, 6).map((service) => {
              const IconComp = iconMap[service.icon] || Cpu;
              return (
                <div key={service.id} className="group p-8 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-white hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                  <div className="w-14 h-14 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <IconComp size={28} />
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 mb-4">{service.title}</h4>
                  <p className="text-slate-600 leading-relaxed mb-6">{service.description}</p>
                  <a href={`#${RoutePath.SERVICES}`} className="text-blue-600 font-semibold flex items-center gap-2 group-hover:gap-3 transition-all">
                    Learn More <ArrowRight size={18} />
                  </a>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <div className="relative">
                <img 
                  src="https://picsum.photos/seed/tech/800/600" 
                  alt="Business Team" 
                  className="rounded-3xl shadow-2xl"
                />
                <div className="absolute -bottom-10 -right-10 bg-blue-600 p-8 rounded-3xl text-white hidden md:block shadow-xl">
                  <p className="text-4xl font-bold mb-1">15+</p>
                  <p className="text-blue-100 font-medium">Years of Excellence</p>
                </div>
              </div>
            </div>
            <div className="lg:w-1/2">
              <h2 className="text-blue-600 font-bold uppercase tracking-widest text-sm mb-4">Why Statvion</h2>
              <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Expertise You Can Trust</h3>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                We combine industry-leading technical knowledge with strategic business insight to deliver results that exceed expectations.
              </p>
              <ul className="space-y-4">
                {['Client-Centric Approach', 'Cutting-Edge Technology', 'Strategic Business Consulting', 'Transparent Communication', 'Agile Methodology', '24/7 Global Support'].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-slate-700 font-medium">
                    <CheckCircle2 className="text-blue-600" size={24} />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-blue-600 rounded-[2.5rem] p-12 lg:p-20 text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <div className="relative z-10">
              <h3 className="text-3xl md:text-5xl font-bold text-white mb-6">Ready to scale your business?</h3>
              <p className="text-blue-100 text-lg mb-10 max-w-2xl mx-auto">
                Join hundreds of industry leaders who have transformed their operations with STATVION INFOTECH.
              </p>
              <a href={`#${RoutePath.CONTACT}`} className="inline-block bg-white text-blue-600 px-10 py-4 rounded-full font-bold text-lg hover:bg-blue-50 transition-colors shadow-lg shadow-blue-800/20">
                Contact Us Today
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
